/*对于Qt进行整改，以从机为模板*/
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFont>//字体
#include <QTime>//时间
#include <QTimer>//时间
#include <qdatetime.h>//日期
#include <QMovie>//加入动图
#include <QPainter>
#include <QPaintEvent>
#include "xlsx.h"//表格操作
#include <QDebug>
#include <QByteArray>
#include <QMessageBox>//对话框
#include <QBitmap>
#include <QFile>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    //menu优化
    ui->menu->setAttribute(Qt::WA_TranslucentBackground); //Menu背景透明
    ui->menu->setWindowFlags(ui->menu->windowFlags()  | Qt::FramelessWindowHint | Qt::NoDropShadowWindowHint);
    ui->menu_E->setAttribute(Qt::WA_TranslucentBackground); //Menu背景透明
    ui->menu_E->setWindowFlags(ui->menu->windowFlags()  | Qt::FramelessWindowHint | Qt::NoDropShadowWindowHint);
    ui->menu_H->setAttribute(Qt::WA_TranslucentBackground); //Menu背景透明
    ui->menu_H->setWindowFlags(ui->menu->windowFlags()  | Qt::FramelessWindowHint | Qt::NoDropShadowWindowHint);
    ui->menu_T->setAttribute(Qt::WA_TranslucentBackground); //Menu背景透明
    ui->menu_T->setWindowFlags(ui->menu->windowFlags()  | Qt::FramelessWindowHint | Qt::NoDropShadowWindowHint);

    InitPort();
    //设置时间
    timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(timerUpdata()));
    timer->start(1000);
    this->ui->toolBar->addAction("测试");
    //this->ui->toolBar->addAction("故障");
    this->ui->toolBar->addAction("绘图");
    this->ui->end_test->setEnabled(false);//初始化停止测试按钮，不能使用
    this->ui->start_test->setEnabled(true);//初始化开始测试按钮，能使用

    //临界资源
    source=0;

    //协议信息
    length=0;
    length1=0;
    str="";
    str1="";

    //从机协议标志位
    flag0=0;
    head=30;//0X1E
    tail=205;//0XCD
    data_size0=12;

    //主机协议标志位
    flag_zhu=0;
    head1=104;//0X68
    tail1=43;//0X2B
    data_size1=13;

    //从机初始化参数
    TIGBT="";
    RIGBT="";
    work_phase="NULL";
    mode="NULL";
    work_time=0;
    Top_hit_state="";
    margin_hit_state="";
    R_triangle_hit_state="";
    Bottom_hit_state="";
    fanya="";

    //文件标志位
    row=1;
    flag1=0;
    j=1;
    filename="";
}
//初始化串口号
void MainWindow::InitPort()
{
    const auto infos = QSerialPortInfo::availablePorts();
    for(const QSerialPortInfo &info : infos)
    {
        QSerialPort serial;
        serial.setPort(info);
        if(serial.open(QIODevice::ReadWrite))
        {
            ui->chuankou_button->addItem(info.portName());
            serial.close();
        }
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}

//设置时间
void MainWindow::timerUpdata(){
    QFont font("黑体",15,1);
    QDateTime time = QDateTime::currentDateTime();
    time_china1 = time.toString("yyyy-MM-dd hh:mm:ss dddd");
    time_china2 = time.toString("yyyy-MM-dd hh:mm:ss");
    time_china3 = time.toString("hh:mm:ss");
    ui -> label_3 ->setFont(font);
    this -> ui->label_3->setText(time_china1);
}

//重写绘图事件,设置背景图片
void MainWindow::paintEvent(QPaintEvent *){
    QPainter p(this);
    p.drawPixmap(rect(),QPixmap(":/new/prefix1/picture/bg3 (2).jpg"));
}

//计时工作时间
void MainWindow::showParameter(){
    work_time++;
    ui->work_time_label->setText(QString::number(work_time)+"s");
}

void MainWindow::on_start_test_released()
{
    //启动定时器
    timer1 = new QTimer(this);
    connect(timer1,SIGNAL(timeout()),this,SLOT(showParameter()));
    timer1->start(1000);
    //配置串口信息
    serialPort = new QSerialPort;

    serialPort->setPortName(ui->chuankou_button->currentText());

    if(serialPort->open(QIODevice::ReadWrite))
    {
        switch (ui->bote_button->currentIndex()) {
        case 0:
            serialPort->setBaudRate(QSerialPort::Baud2400);
            break;
        case 1:
            serialPort->setBaudRate(QSerialPort::Baud4800);
            break;
        default:
            break;
        }
        switch (ui->stop_button->currentIndex()) {
        case 0:
            serialPort->setStopBits(QSerialPort::OneStop);
            break;
        case 1:
            serialPort->setStopBits(QSerialPort::TwoStop);
            break;
        default:
            break;
        }

        switch (ui->data_button->currentIndex()) {
        case 0:
            serialPort->setDataBits(QSerialPort::Data5);
            break;
        case 1:
            serialPort->setDataBits(QSerialPort::Data6);
            break;
        case 2:
            serialPort->setDataBits(QSerialPort::Data7);
            break;
        case 3:
            serialPort->setDataBits(QSerialPort::Data8);
            break;
        default:
            break;
        }

        switch (ui->jiou_button->currentIndex()) {
        case 0:
            serialPort->setParity(QSerialPort::NoParity);
            break;
        case 1:
            serialPort->setParity(QSerialPort::OddParity);
            break;
        case 2:
            serialPort->setParity(QSerialPort::EvenParity);
            break;
        default:
            break;
        }
        connect(serialPort, &QSerialPort::readyRead, this, &MainWindow::readToHex);
        //控件操作
        this->ui->start_test->setEnabled(false);
        this->ui->end_test->setEnabled(true);

        ui->chuankou_button->setEnabled(false);
        ui->stop_button->setEnabled(false);
        ui->bote_button->setEnabled(false);
        ui->jiou_button->setEnabled(false);
        ui->data_button->setEnabled(false);
    }
    else
    {
        QMessageBox::critical(this, tr("Error"), serialPort->errorString());
    }
}

void MainWindow::on_end_test_released()
{

    //关闭定时器
    timer1->stop();
    disconnect(timer1,SIGNAL(timeout()),this,SLOT(showParameter()));
    work_time=0;
    flag0=0;
    length=0;
    //控件操作
    this->ui->start_test->setEnabled(true);
    this->ui->end_test->setEnabled(false);

    ui->chuankou_button->setEnabled(true);
    ui->stop_button->setEnabled(true);
    ui->bote_button->setEnabled(true);
    ui->jiou_button->setEnabled(true);
    ui->data_button->setEnabled(true);

    serialPort->clear();
    serialPort->close();
    serialPort->deleteLater();
    disconnect(serialPort, &QSerialPort::readyRead, this, &MainWindow::readToHex);
}

//读取十六进制，读取协议信息
void MainWindow::readToHex()
{
    int receBytes=0;
    QByteArray temp = serialPort->readAll();
    //auto isShow = ui->reDisplay->isChecked();         //接收显示
    receBytes += temp.size();
    QString redata = QString("received:%1").arg(QString::number(receBytes));
    //ui->sendlabel->setText(redata);
    QDataStream out(&temp,QIODevice::ReadOnly);    //将字节数组读入
    while(!out.atEnd())
    {
        quint8 outChar = 0;
        out>>outChar;   //每字节填充一次，直到结束
        //获取从机协议
        if(flag0==0){
            //head
            if(flag_zhu==0&&outChar==head){
                //qDebug()<<"outChar==104  "<<length;
                flag0=1;
                //write
                treaty[length++]=outChar;
            }
        }
        else if(flag0==1&&flag_zhu==0){
            //tail、length、solve
            treaty[length++]=outChar;
            if(outChar==tail&&length==16){
                flag0=0;
                solve(length);
                length=0;
            }
        }

        //获取主机协议
        if(flag_zhu==0){
            //head
            if(flag0==0&&outChar==head1){
                //qDebug()<<"outChar==104  "<<length;
                flag_zhu=1;
                //write
                treaty1[length1++]=outChar;
            }
        }
        else if(flag0==0&&flag_zhu==1){
            //tail、length、solve
            treaty1[length1++]=outChar;
            if(outChar==tail1&&length1==17){
                flag_zhu=0;
                solve1(length1);
                length1=0;
            }
        }

    }
}
//处理从机协议
bool MainWindow::solve(int length){
    //当row==1501时，重新建新文件
    if(row%1501==1){
        row=1;
        //将第一行写入文件
        QStringList list;
        list <<"北京时间"<<ui->TIGBT_label->text()<<ui->RIGBT_label->text()<<ui->work_phase->text()
             <<ui->mode_label->text()<<ui->work_time->text()<<ui->top_hit_state->text()
             <<ui->m_hit_state->text()<<ui->R_hit_state->text()<<ui->b_hit_state->text()
             <<ui->TTAD->text()<<ui->treaty_label_2->text();
        xlsx::writeRow(xlsx, list, row++, 1);
        filename="从机数据"+QString::number(j++)+".xlsx";
         qDebug()<<filename;
        xlsx.saveAs(filename);
    }
    if(length!=16)
        return false;

    //保存整体协议
    str="";
    for(int i=0;i<length;i++){
        str=str+QString("%1").arg(treaty[i]&0xFF,2,16,QLatin1Char('0'));
    }

    //反压、过流、浪涌
    quint8 temp01;
    temp01=treaty[6]&0X38;
    if(temp01==0){
        fanya="无";//反压
        R_triangle_hit_state="无";//过流
        work_phase="无";//浪涌
    }else if(temp01==8){
        fanya="无";//反压
        R_triangle_hit_state="无";//过流
        work_phase="有";//浪涌
    }else if(temp01==16){
        fanya="无";//反压
        R_triangle_hit_state="有";//过流
        work_phase="无";//浪涌
    }else if(temp01==24){
        fanya="无";//反压
        R_triangle_hit_state="有";//过流
        work_phase="有";//浪涌
    }else if(temp01==32){
        fanya="有";//反压
        R_triangle_hit_state="无";//过流
        work_phase="无";//浪涌
    }else if(temp01==40){
        fanya="有";//反压
        R_triangle_hit_state="无";//过流
        work_phase="有";//浪涌
    }else if(temp01==48){
        fanya="有";//反压
        R_triangle_hit_state="有";//过流
        work_phase="无";//浪涌
    }else if(temp01==56){
        fanya="有";//反压
        R_triangle_hit_state="有";//过流
        work_phase="有";//浪涌
    }

    //步骤0-5
    quint8 temp02;
    temp02=treaty[2]&0XE0;
    if(temp02==0)
        mode="步骤0";
    else if(temp02==32)
        mode="步骤1";
    else if(temp02==64)
        mode="步骤2";
    else if(temp02==96)
        mode="步骤3";
    else if(temp02==128)
        mode="步骤4";
    else if(temp02==160)
        mode="步骤5";
    else
        mode="NULL";
    //qDebug()<<mode;

    Bottom_hit_state=QString("%1").arg(treaty[8]);//底部温度
    Top_hit_state=QString("%1").arg(treaty[9]);//顶部温度
    TIGBT=QString("%1").arg(treaty[11]);//IGBT1温度
    RIGBT=QString("%1").arg(treaty[10]);//IGBT2温度

    //蜂鸣
    quint8 temp03;
    temp03=treaty[7]&0X03;
    if(temp03==0)
        margin_hit_state="无蜂鸣";
    else if(temp03==1)
         margin_hit_state="有蜂鸣";

    ui->treaty_1->setText(str);//协议

    ui->TIGBT_->setText(TIGBT);//IGBT1温度
    ui->RIGBT_->setText(RIGBT);//IGBT2温度
    ui->mode_->setText(mode);//工作步骤
    ui->top_hit_->setText(Top_hit_state);//顶部温度
    ui->b_hit_->setText(Bottom_hit_state);//底部温度

    ui->TTAD_label->setText(fanya);//反压
    ui->R_hit_->setText(R_triangle_hit_state);//过流
    ui->work_phase_label->setText(work_phase);//浪涌
    ui->m_hit_->setText(margin_hit_state);//蜂鸣

    //将获取para写入xlsx
    QStringList list;
    //QString("%1").arg(TTT)将float转QString
    list <<time_china3<<QString("%1").arg(TIGBT)<<QString("%1").arg(RIGBT)<<work_phase<<mode
         <<QString("%1").arg(work_time)<<Top_hit_state<<margin_hit_state
         <<R_triangle_hit_state<<Bottom_hit_state<<fanya<<str;
    xlsx::writeRow(xlsx, list, row++, 1);
    xlsx.saveAs(filename);
    return true;
}
//处理主机协议
bool MainWindow::solve1(int length1){
    //保存整体协议
    str1="";
    for(int i=0;i<length1;i++){
        str1=str1+QString("%1").arg(treaty1[i]&0xFF,2,16,QLatin1Char('0'));
    }

}


//鼠标双击特效
void MainWindow::mouseDoubleClickEvent(QMouseEvent *event)
{

    //判断是否为鼠标左键双击
    if(event->button() == Qt::LeftButton)
    {
        QLabel * label = new QLabel(this);
        QMovie * movie = new QMovie(":/new/prefix1/picture/mouse_clicked.gif");//加载gif图片
        //设置label自动适应gif的大小
        label->setScaledContents(true);

        label->setMovie(movie);
        //这里为了调用move方便，进行resize，需要知道的是gif的大小本来也就是150*150
        label->resize(180,180);
        label->setStyleSheet("background-color:rgba(0,0,0,0);");
        //设置鼠标穿透
        label->setAttribute(Qt::WA_TransparentForMouseEvents, true);
        //让label的中心在当前鼠标双击位置
        label->move(event->pos().x()-label->width()/2,event->pos().y()-label->height()/2);
        //开始播放gif
        movie->start();

        label->show();

        //绑定QMovie的信号，判断gif播放次数
        connect(movie, &QMovie::frameChanged, [=](int frameNumber) {
            if (frameNumber == movie->frameCount() - 1)//gif播放次数为1，关闭标签
                label->close();
        });
    }
}
